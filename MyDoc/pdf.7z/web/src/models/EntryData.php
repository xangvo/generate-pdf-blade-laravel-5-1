<?php

namespace Pms\Web;

use Pms\Base\BaseModel;

class EntryData extends BaseModel 
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'entrydata';

    public $timestamps = false;
    protected $primaryKey = 'receptionNumber';
    
    public function getUserTelAttribute()
    {
        return implode('-', array_filter([ $this->userTel_area, $this->userTel_city, $this->userTel_num ]));
    }

    public function getMobileTelAttribute()
    {
        return implode('-', array_filter([ $this->mobileTel_area, $this->mobileTel_city, $this->mobileTel_num ]));
    }

    public function getOfficeTelAttribute()
    {
        return implode('-', array_filter([ $this->officeTel_area, $this->officeTel_city, $this->officeTel_num ]));
    }

    public function getUserNameKanaAttribute()
    {
        return $this->userSurname_kana . ' ' . $this->userGivenname_kana;
    }

    public function getUserNameAttribute()
    {
        return $this->userSurname . ' ' . $this->userGivenname;
    }

}
