<?php

namespace Pms\Web;

use Illuminate\Database\Eloquent\Model;

class AccessData extends Model 
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'accessdata';

    public $timestamps = false;
    
    
}
