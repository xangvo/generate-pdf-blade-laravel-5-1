<?php

namespace Pms\Web;

use Illuminate\Database\Eloquent\Model;

class BranchData extends Model 
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'branchdata';

    public $timestamps = false;
    
    
}
