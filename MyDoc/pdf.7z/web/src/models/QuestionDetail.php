<?php

namespace Pms\Web;

use Illuminate\Database\Eloquent\Model;

class QuestionDetail extends Model 
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'questiondetail';

    public $timestamps = false;
    
    
}
