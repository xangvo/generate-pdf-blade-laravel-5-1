<?php

return array(

    /**
     *
     * @return Array
     */
    'rules_search' => [
        'dateFrom' => ''
        , 'dateTo' => ''
        , 'coursecode' => ''
        , 'receptionNumber' => ''
        , 'userSur1name' => ''
        , 'userGiven1name' => ''
        , 'userSur1name_kana' => ''
        , 'userGivenname_kana' => '',
    ],
    'upload_csv_file_rules' => [
        'branchCodeFile' => 'max:25600|mimes:csv,txt', //25MB
        // 'branchCodeFile'   => 'max: 1024',//1MB
    ],

    'import_csv_rules' => array(
        // 'bankcode' => 'max :1'
         'code' => 'max:10'
        , 'name' => 'max:40'
        , 'kana' => 'max:50',
    ),

    'access_analysis_search_rules' => [
        'dateFrom' => 'date|required',
        'dateTo' => 'date|required|aftersearch:dateFrom',
    ],

);
