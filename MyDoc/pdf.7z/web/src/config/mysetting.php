<?php

/*
|--------------------------------------------------------------------------
|--------------------------------------------------------------------------
*/
return array(

	'campaign_is_being_implemented_or_will_be_implemented' => 'now',
	'number_of_record_perpage'                             => 20,
    'DB_error'                                             => 'データベースエラーが発生しました',
    'no_record'                                            => '該当データがありません',
    'not_correct_format'                                   => 'アップロードファイルの形式が正しくありません。',
    'not_allowed_upload'                                   => 'ファイルをアップロードできませんでした。',
    'csvFileName'                                          => 'branchdata.csv',
    'batchFileFolder'                                      => storage_path() . "/batchFileFolder/",
    'columns_branchdata_export' =>
                                array(
                                    '店番',
                                    '枝番',
                                    '店名',
                                    'フリガナ',
                                ),
    'columns_branchdata_import' =>
                                array(
                                    'bankcode',
                                    'code',
                                    'name',
                                    'kana',
                                ),                                
    'default_encoding_list' => array(
        "ASCII"
        ,"SJIS"
        ,"JIS"
        ,"UTF-8"
    ),
	'product_category' => [
                            ''  => '選択してください',
							0   => '1.クイックカードローン'
                           , 4  => '2.プレミアムカードローン'
                           , 16 => '3.カードローン（住宅ローンセット型）'
                           , 3  => '4.プライベートローンＪ'
                           , 9  => '5.マイカーローン'
                           , 8  => '6.教育ローン'
                           , 10 => '7.リフォームローン'
                           , 14 => '8.プレミアムフリーローン'
                        ],
    'product_loan_category' => [
							'' => '選択してください'
							,1  => 'カードローン'
							,2 => 'フリーローン'
							,3 => 'マイカーローン'
							,4 => '教育ローン'
							,5 => 'リフォームローン'
                        ],
    'batchType_timeMap' => [
                '1'  => '8:00',
                '2'   => '9:00'
                , '3'  => '9:30'
                , '4' => '10:00'
                , '5'  => '10:30'
                , '6'  => '11:00'
                , '7'  => '11:30'
                , '8' => '12:00'
                , '9' => '12:30'
                , '10' => '13:00'
                , '11' => '13:30'
                , '12' => '14:00'
                , '13' => '14:30'
                , '14' => '15:00'
    ],
    'questiondetail_content' => [
                                ['questno' => '01', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '02', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '03', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '04', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '05', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '06', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '07', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '08', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '09', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '10', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '11', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '12', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '13', 'cont' => '' , 'openflg' => 0],
                                ['questno' => '99', 'cont' => '' , 'openflg' => 0],
    ],
);
