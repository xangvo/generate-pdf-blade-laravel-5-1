<?php

return array(
    'coursecode'                          => '商品',
    'dateFrom'                            => '取扱期間FROM',
    'dateTo'                              => '取扱期間TO',
    'receptionNumber'                     => '受付番号',
    'userSur1name'                        => '氏',
    'userGiven1name'                      => '名',
    'userSur1name_kana'                   => '氏(カナ)',
    'userGiven1name_kana'                 => '名(カナ)',
);

