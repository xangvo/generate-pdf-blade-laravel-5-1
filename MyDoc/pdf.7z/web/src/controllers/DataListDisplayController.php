<?php

namespace Pms\Web;

use App\Campaign;
use Validator;
use DB;
use Pms\Web\EntryData;
use Pms\Base\BaseController;
use Pms\Base\ProductMaster;

class DataListDisplayController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->screenID ='WM004';
        $this->titlePage = 'データ一覧表示';
        $this->rules = config('web.rules.rules_search');
        $this->attributes = config('web.items');
    }

    /**
     * this function is used to list and display data for WM004
     *
     * @return void
     */
    public function init()
    {
        parent::init();

        //get input request
        $input = $this->getRequestInputs();
        //get info from Session when Back
        $inputBack = $this->getInput($this->screenID);

        //Get bank_type from URL
        $bankType = $this->getBankTypeID();
        //get user info from Session
        $userInfo = [];
        
        //get master product category
        $m_product_category_master = ProductMaster::where('bankcode', $this->getBankTypeID() )->get();
        if(count($m_product_category_master) > 0) {
            $m_product_category_master = $m_product_category_master->toArray();
        }
        $m_product_category = [];
        foreach ($m_product_category_master as $key => $value) {
            $m_product_category[$value['productcode']] = $value['productname'];
        }


        //set default flag to know search or not
        $flgSearch = false;
        if (\Request::isMethod('get')) {
            //if not paging
            if (!isset($input['page'])) {
                //forget session about entry input
                session()->forget('entryinput');
                //get first date of this current month
                $dateFrom = $this->formatDate(date('Ym01'));
                //get end date of current month
                $dateTo = $this->formatDate(date('Ymt'));
                
                //get default data
                $data = $post = [];
                //set total
                $total = 0;
                
            } else {
                
                //get input from  old  entryinput session
                $input =   session('entryinput');
                //using post variable to keep old input 
                $post = $input;
                //format date before rending into html
                if(isset($input['dateFrom'])){
                    $dateFrom = $this->formatDate($input['dateFrom']);
                }
                if(isset($input['dateTo'])){
                    $dateTo = $this->formatDate($input['dateTo']);
                }

                //implement searching
                $returnData = $this->searchData($input);
                if($returnData  ==='db_error') {
                    return back()->withInput($input)->withErrors(['db_error' => true, 'db_error_message' => config('web.mysetting.DB_error') ]);
                } else {
                        $flgSearch = true;
                        $total = $returnData['total'];
                        $data = $returnData['data'];
                }
            }
        } else {
            //Validate input search:
            $validator = $this->getValidator($input);
            //If validation failed
            if ($validator->fails()) {
                return back()->withInput($input)->withErrors($validator);
            } else {
                // prepare date from for rendering HTML
                if(isset($input['dateFrom'])){
                    $dateFrom = $this->formatDate($input['dateFrom']);
                }
                // prepare date to for rendering HTML
                if(isset($input['dateTo'])){
                    $dateTo = $this->formatDate($input['dateTo']);
                }

                //using post variable to keep old input 
                $post = $input;
                //save input  into  entryinput session 
                session(['entryinput' => $input]);
                //implement searching
                $returnData = $this->searchData($input);

                if($returnData  ==='db_error') {
                    return back()->withInput($input)->withErrors(['db_error' => true, 'db_error_message' => config('web.mysetting.DB_error') ]);
                } else {
                        $flgSearch = true;
                        $total = $returnData['total'];
                        $data = $returnData['data'];
                }
            }
        }
       
        return $this->view('web::datadisplay.index', [
                                                    'data'               => $data,
                                                    'total'              => $total,
                                                    'flgSearch'          => $flgSearch,
                                                    'm_product_category' => $m_product_category,
                                                    'dateFrom'           => $dateFrom,
                                                    'dateTo'             => $dateTo,
                                                    'post'               => $post,
                                                ]);
    }

    /**
     * this function is ued to search entry data
     *
     * @return $returnData
     */
    private function searchData($input)
    {
        //define default return data
        $returnData =  ['total' => 0, 'data' =>[]];
        
        //get input:
        $dateFrom           = $input['dateFrom'];
        $dateTo             = $input['dateTo'];
        $userSurname        = $input['userSur1name'];
        $userGivenname      = $input['userGiven1name'];
        $userSurname_kana   = $input['userSur1name_kana'];
        $userGivenname_kana = $input['userGiven1name_kana'];
        $product            = $input['coursecode'];
        $receptionNumber    = $input['receptionNumber'];
        //format date for IE
        if(!empty($dateFrom)){
            $dateFrom = str_replace( '/','-', $dateFrom);
        }

        if(!empty($dateTo)){
            $dateTo = str_replace( '/','-', $dateTo);
        }

        //Implement searching
        //Step 1: Get data list
         try {
            if(!empty($dateFrom) && !empty($dateTo)){
                $entrydata = $this->commonSelectQuery();
                $entrydata = $entrydata->whereBetween('receptionDate', [$dateFrom, $dateTo]);
            }
            if(empty($dateFrom) && !empty($dateTo)){
                $entrydata = $this->commonSelectQuery();
                $entrydata = $entrydata->where(DB::raw("date(receptionDate)"), '<=', $dateTo);
            }
            if(!empty($dateFrom) && empty($dateTo)){
                $entrydata = $this->commonSelectQuery();
                $entrydata = $entrydata->where(DB::raw("date(receptionDate)"), '>=', $dateFrom);
            }
            if(empty($dateFrom) && empty($dateTo)){
                $entrydata = $this->commonSelectQuery();
            }
            
        } catch (\PDOException $e) {
                //set db_error
                return 'db_error';
            }
            
        if (!empty($userSurname)) {
            $entrydata = $entrydata->where('userSurname', $userSurname);
        }
        if (!empty($userGivenname)) {
            $entrydata = $entrydata->where('userGivenname', $userGivenname);
        }
        if (!empty($userSurname_kana)) {
            $entrydata = $entrydata->where('userSurname_kana', $userSurname_kana);
        }
        if (!empty($userGivenname_kana)) {
            $entrydata = $entrydata->where('userGivenname_kana',$userGivenname_kana);
        }

        if (!empty($product)) {
            $entrydata = $entrydata->where('coursecode', $product);
        }

         if (!empty($receptionNumber)) {
            $entrydata = $entrydata->where('receptionNumber', $receptionNumber);
        }
       
        //Get total record
        $total = count($entrydata->get());
        //implement pagination
        $data = $entrydata->paginate(20);
        
        $returnData =  ['total' => $total, 'data' =>$data];
        return $returnData;
    }

    /**
     * this function is used to select query
     *
     * @return void
     */
    private function commonSelectQuery(){
        $entrydata = EntryData::select(
                                    'receptionDate',
                                    'receptionNumber',
                                    'userSurname',
                                    'userGivenname',
                                    'userSurname_kana',
                                    'userGivenname_kana',
                                    'emailAddress',
                                    'mailsendFlag'
        );
        return $entrydata;
    }
    
    /**
     * this function is used to format date
     *
     * @param [type] $inputDate
     * @return void
     */
    private function formatDate($inputDate){

        if(empty($inputDate)){
            return $inputDate;
        } else {
            //format inputdate into the same output yyyymmdd
            $formatDate = str_replace( '-','', $inputDate);
            $formatDate = str_replace( '/','', $inputDate);

            //validate date
            $rule = ['ruleDate'   => 'date_format:"Ymd"'];
            $validateInput = ['ruleDate' => $formatDate];
            $valid = Validator::make($validateInput, $rule);
            if (!$valid->fails()) {
                $formatDate = date_create_from_format('Ymd', $formatDate)->format('Y-m-d');
                return $formatDate;
            }
            return $inputDate;
        }
    }

    /**
     * Export data search to PDF
     *
     * @return pdf file
     */
    public function exportPDF()
    {
        //Get input request
        $input = $this->getRequestInputs();
        $returnData = $this->searchData($input);
        $data = $returnData['data'];
        $total = $returnData['total'];

        if(empty($data)){
            return \Redirect::back();
        }

        $exportLeftColumns = config('web.export_columns.left_column');
        $exportRightColumns = config('web.export_columns.right_column');

        $pdfFileName = 'entry_T_' . date('YmdHis') . '_連番.pdf';
        $pdf = \PDF::loadView('web::datadisplay.pdf', compact('data', 'total', 'pdfFileName', 'exportLeftColumns', 'exportRightColumns'));
        $pdf->setPaper('A4', 'portrait');
        
        return $pdf->download($pdfFileName);

        return $this->view('web::datadisplay.pdf', compact('data', 'total', 'pdfFileName', 'exportLeftColumns', 'exportRightColumns'));
    }

    /**
     * Export data search to CSV
     *
     * @return pdf file
     */
    public function exportCSV()
    {
        //Get input request
        $input = $this->getRequestInputs();
        $returnData = $this->searchData($input);
        $data = $returnData['data'];
        if(empty($data)){
            return \Redirect::back();
        }

        //define filename
        $csvFileName = 'entry_T_' . date('YmdHis') . '_連番.csv';
        $columns = config('web.export_columns.left_column') + config('web.export_columns.right_column');
        $headerArr = array_keys($columns);
        $valueArr = array_values($columns);

        header('Content-type: application/csv');
        header('Content-Disposition: attachment; filename="'.$csvFileName.'"');
        header("Content-Transfer-Encoding: Shift-JIS");
        //Open temp file
        $fp = fopen('php://output', 'a');

        //create csv file
        fputcsv($fp, $headerArr);

        foreach ($data as $value) {
            $row = [];
            foreach ($valueArr as $col) {
                $row[] = $value->$col;
            }
            fputcsv($fp, $row);
        }
        
        //close file
        fclose($fp);

        //Process to download
        $encoded = mb_convert_encoding(file_get_contents('php://output'), 'UTF-8', 'Shift-JIS');

        return response((string) $encoded, 200, [
                    'Content-Type' => 'application/csv',
                    'Content-Transfer-Encoding' => 'binary',
                    'Content-Disposition' => 'attachment; filename="'.$csvFileName.'"',
                ]);
    }

}
