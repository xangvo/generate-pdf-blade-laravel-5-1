<?php

namespace Pms\Web;

use App\Campaign;
use Pms\Web\BranchData;
use Validator;
use DB;
use Illuminate\Support\MessageBag;
use Pms\Base\BaseController;

class ShopManageController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->screenID ='WM007';
        $this->titlePage = '店舗情報管理';
        $this->rules = config('web.rules.import_csv_rules');
    }

    /**
     * this function is used to list branch data page
     *
     * @return void
     */
    public function init()
    {
        parent::init();
        $data = [];
        //set default db_error
        $db_error = false;
        //get all branch data
        try {
            $data = BranchData::where('bankcode', $this->getBankTypeID())->get();
        } catch (\PDOException $e) {
            //set db_error
            $db_error = true;
        }
        return $this->view('web::shopmanage.index', array('data' => $data, 'db_error' => $db_error ));
    }


    /**
     * this function is used to upload branch code file into table branchdata
     *
     * @return void
     */
    public function postUpload()
    {
        //get input request
        $input = $this->getRequestInputs();
        $uploadRules = config('web.rules.upload_csv_file_rules');
        //get upload file
        $targetfile = \Request::file('branchCodeFile');
        //validate format of file type & file size
        $validator = Validator::make($input, $uploadRules);
        if ($validator->fails()) {
            $error =  $validator->messages()->first('branchCodeFile');
            if ($error  == ' 25600 kB以下のファイルをご指定ください。') {
                //custom message
                $error = config('web.mysetting.not_allowed_upload');
            } else {
                $error = config('web.mysetting.not_correct_format');
            }
            return back()->withInput($input)->withErrors(['not_correct_format' => $error]);
        }

        //define default error flag to check content of upload file
        $isError = false;
        //define error message
        $errMsg = new MessageBag();
        //get the columns of table branchdata from setting file
        $columns  = config('web.mysetting.columns_branchdata_export');
        $columnRomanji  = config('web.mysetting.columns_branchdata_import');
        //define dataImport
        $dataImport = array();

        //check encoding of upload file
        $isCorrectEncoding = $this->checkEncodingOfUploadFile($targetfile);
        if(!$isCorrectEncoding) {
            $isError = true;
        }

        setlocale(LC_ALL, 'ja_JP.UTF-8');
        //get content of uploaded file
        $data = file_get_contents($targetfile);
        $encodingList = config('web.mysetting.default_encoding_list', mb_list_encodings());
        
        $encoding      = mb_detect_encoding($data, $encodingList, true);
        if ($encoding == false) {
            //check encoding
            return back()->withInput($input)->withErrors(['not_correct_format' => config('web.mysetting.not_correct_format')]);
        } else {
            //convert encoding
            $data = mb_convert_encoding($data, 'UTF-8', $encoding);
        }
        //creates a temporary file with a unique name in read-write (w+) mode.
        $temp = tmpfile();
        //writes to an open file $temp
        fwrite($temp, $data);
        //"rewinds" the position of the file pointer to the beginning of the file.
        rewind($temp);

        //Process to get the content of upload CSV file
        //start to get and check content of upload file+++++++++++++++++++++++++++++
        $data = fgetcsv($temp);
        if (count(array_diff($data, $columns)) > 0) {
            //if wrong number of column, no need to process anymore
            return back()->withInput($input)->withErrors(['not_correct_format' => config('web.mysetting.not_correct_format')]);
        }
        
        while ($data = fgetcsv($temp)) {
            if ($data != '') {
                $input = array();
                //validate the number of columns in each row
                if (count($data) != count($columns)) {
                    $isError = true;
                }
                foreach ($data as $k => $d) {
                    if (isset($columns[$k])) {
                        $input[$columnRomanji[$k]] =  $d;
                    }
                }
                //validate the number of columns of imported file
                if (count($input) != count($columns)) {
                    $isError = true;
                }
                
                //Process to validate the content of imported CSV file
                //check bankcode
                $bankCodeRule = ['bankcode'       => 'max:1|in:'.$this->getBankTypeID().''];
                $this->rules += $bankCodeRule;
                $validator = Validator::make($input, $this->rules);
                if ($validator->fails()) {
                    $isError = true;
                }
                //assign data to prepare for insert data
                $dataImport[] = $input;
            }
        }
        
        //Validate duplicate row in $dataImport
        //define array to keep and check duplicate (bankcode,code)
        $arrayBankCodeCode = [];
        foreach ($dataImport as $key => $value) {
            $arrayBankCodeCode[] = $value['bankcode'].$value['code'];
        }
        //if duplicate (bankcode,code)
        if (count($arrayBankCodeCode)  != count(array_unique($arrayBankCodeCode))) {
            $isError = true;
        }
        //end get and check content of upload file-----------------------
        if ($isError == true) {
            return back()->withInput($input)->withErrors(['not_correct_format' => config('web.mysetting.not_correct_format')]);
        }

        DB::beginTransaction();
        BranchData::where('bankcode', $this->getBankTypeID())->delete();
        
        foreach ($dataImport as $input) {
            DB::table('branchdata')->insert($input);
        }
        
        if ($errMsg->isEmpty()) {
            DB::commit();
        } else {
            DB::rollBack();
            return back()->withInput($input)->withErrors(['not_correct_format' => config('web.mysetting.not_correct_format')]);
        }

        return redirect()->route('action-shop-manage');
    }

    /**
     * this function is used to download CSV file
     *
     * @return void
     */
    public function downloadCSV()
    {
        //define filename
        $filename  = $this->screenID.'_'.date('Ymd').'_'.date('His').'.csv';
        $columns  = config('web.mysetting.columns_branchdata_export');

        header('Content-type: application/csv');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header("Content-Transfer-Encoding: Shift-JIS");
        //open temp file
        $fp = fopen('php://output', 'a');
        //fputcsv($fp, $key);

        // Get campaignCode from CampaignCodeData
        $tmp = [];
        $tmp = BranchData::where('bankcode', $this->getBankTypeID())->get();
        if (!empty($tmp)) {
            $tmp = $tmp->toArray();
        }
        //create csv file
        fputcsv($fp, $columns);
        foreach ($tmp as $k => $row) {
            fputcsv($fp, $row);
        }
        //close file
        fclose($fp);

        //Process to download
        //$filepath .=$filename;
        $encoded = mb_convert_encoding(file_get_contents('php://output'), 'UTF-8', 'Shift-JIS');
        //file_put_contents($filepath, $encoded);
        return response((string) $encoded, 200, [
                    'Content-Type' => 'application/csv',
                    'Content-Transfer-Encoding' => 'binary',
                    'Content-Disposition' => 'attachment; filename="'.$filename.'"',
                ]);
        //return \Response::download('php://output');
    }

    private function checkEncodingOfUploadFile($targetfile) {
        $contentOfFile = file_get_contents($targetfile);
        $currentEncoding = mb_detect_encoding($contentOfFile,'ASCII,UTF-8,SHIFT_JIS,SJIS*,JIS');
        if(($currentEncoding=='SJIS') || ($currentEncoding=='UTF-8') || ($currentEncoding=='ASCII')){
            return true;
        } else {
            return false;
        }
    }

    
}
