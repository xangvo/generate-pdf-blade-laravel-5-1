<?php

namespace Pms\Web;

use Pms\Base\BaseController;
use Auth;
use Validator;
use DB;
use Pms\Web\EntryData;
use Pms\Batch\BatchData;
use Illuminate\Http\Request;


class EntryDataDownloadController extends BaseController
{
    protected $campaignData = [];

    public function __construct()
    {
        parent::__construct();
        $this->screenID = 'WM002';
        $this->titlePage = 'ファイルのダウンロード画面';
    }


    /**
      * this  function is used to  list data in batchdata table
      * screen ID: WM002
      * @return void
      */
    public function init()
    {
        parent::init();

        //get input request
        $input = $this->getRequestInputs();
        //get info from Session when Back 
        $inputBack = $this->getInput($this->screenID);
        //Get bank_type from URL
        $bankType = $this->getBankTypeID();
        //get batchtype and type map
        $batchType_TypeMap = config('web.mysetting.batchType_timeMap');
        //get user info from Session
        $userInfo = [];
        //set default db_error
        $db_error = false;
        //Get data from DB  from SQL
        try {
                // $entryData = EntryData::all()->toArray();//::orderBy('batchtype', 'asc')
                $batchData = BatchData::orderBy(DB::raw('CAST(batchtype AS UNSIGNED)'))->get();
                if(!empty($batchData)){
                    $batchData = $batchData->toArray();
                }
            } catch (\Exception $e) {
                $batchData = [];
                $db_error = true;
            }
        
        $data = [
            'bank_type' => $bankType,
            'user_info' => $userInfo,
            'batchData' => $batchData,
        ];
        //Render HTML 
        return $this->view(
            'web::entrydata.index',
                                array(
                                        'data'              => $data,
                                        'db_error'          => $db_error,
                                        'db_error_msg'      => config('define.DB_error'),
                                        'no_record_msg'     => config('web.mysetting.no_record'),
                                        'batchType_TypeMap' => $batchType_TypeMap,
                                    )
        );
    }

    /**
     * this function is used to download txt or PDF file
     *
     * @return void
     */
    public function download()
    {
        //get file type
        $type =request('type');
        //get file name
        $filename =request('file');
        //Get bank_type from URL
        $bankType = $this->getBankTypeID();
        //get user info from Session
        $userInfo = [];
        //get batchtype and type map
        $batchType_TypeMap = config('web.mysetting.batchType_timeMap');

        //get folder of file
        $folderOfBatchFile = config('web.mysetting.batchFileFolder');
        //check file exist or not
        if (!file_exists($folderOfBatchFile.$filename)) 
        {
            $db_error  = false;
            $data      = [];
            $batchData = [];
        } else {
                //update number of download
                if($type =='txt'){
                    //get number of current download
                    $currentDownload = BatchData::select('downloadflg')->where('file', $filename)->get();
                    if(!empty($currentDownload)){
                        $currentDownload = $currentDownload->toArray();
                        $numberOfDownload = $currentDownload[0]['downloadflg'] + 1;;
                    } else {
                        $numberOfDownload = 1;
                    }
                    BatchData::where('file', $filename)->update(['downloadflg' => $numberOfDownload]);
                } 
                if($type =='pdf'){
                    //get number of current download
                    $currentDownload = BatchData::select('downloadflg')->where('file2', $filename)->get();
                    if(!empty($currentDownload)){
                        $currentDownload = $currentDownload->toArray();
                        $numberOfDownload = $currentDownload[0]['downloadflg'] + 1;
                    } else {
                        $numberOfDownload = 1;
                    }
                    BatchData::where('file2', $filename)->update(['downloadflg' => $numberOfDownload]);
                }
                //Process to download
                $filepath = $folderOfBatchFile. $filename;
                $encoded = mb_convert_encoding(file_get_contents($filepath), 'SJIS-WIN', 'UTF-8');
                file_put_contents($filepath, $encoded);
                return \Response::download($filepath);
        } 
        $data = [
            'bank_type' => $bankType,
            'user_info' => $userInfo,
            'batchData' => $batchData,
        ];

        //Render HTML 
        return $this->view(
            'web::entrydata.index',
                                array(
                                        'data'              => $data,
                                        'db_error'          => $db_error,
                                        'db_error_msg'      => config('define.DB_error'),
                                        'no_record_msg'     => config('web.mysetting.no_record'),
                                        'batchType_TypeMap' => $batchType_TypeMap,
                                    )
                            );
        
    }
   
}
