<?php

namespace Pms\Web;

use Auth;
use Validator;
use DB;

use Pms\Base\BaseController;


class WebListController extends BaseController
{


    public function __construct(){
        parent::__construct();
        $this->screenID ='WM001';
        $this->titlePage = 'メニュー画面';
    }

    /**
     * this function is used to xxxx
     *
     * @return void
     */
    public function init()
    {
        //get input request
        $input = $this->getRequestInputs();
        //get info from Session when Back 
        $inputBack = $this->getInput($this->screenID);
        //Get bank_type from URL
        $bankType = $this->getBankTypeID();
        //get user info from Session
        $userInfo = [];

        $data = [
                'bank_type' => $bankType,
                'user_info' => $userInfo,
                ];
        return $this->view('web::index', array('data' => $data));
    }
    
}
