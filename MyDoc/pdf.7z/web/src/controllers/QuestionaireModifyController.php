<?php

namespace Pms\Web;

use App\Campaign;
use Validator;
use DB;
use Pms\Web\QuestionDetail;

use Pms\Base\BaseController;


class QuestionaireModifyController extends BaseController
{

    CONST COURSECODE = 1;
    public function __construct(){
        parent::__construct();
        $this->screenID ='WM006';
        $this->titlePage = 'アンケート内容一覧';
    }

    /**
     * this function is used to modify question detail data
     *
     * @return void
     */
    public function init()
    {
        parent::init();
        //get bank type from URL
        $bankType = $this->getBankTypeID();
        //get coursecode
        $coursecode = self::COURSECODE;
        $data = [];
        //set default db_error
        $db_error = false;
        //set default mode
        $mode = 'update';
        //get all questiondetail
        try {
            $data = QuestionDetail::where('bankcode', $bankType)
                                    ->where('coursecode', $coursecode)
                                    ->orderBy('questno', 'asc')->get();
        } catch (\PDOException $e) {
                //set db_error
                $db_error = true;
            }
            //dd($data);
        if(count($data) == 0){
            //get from setting file
            $data = config('web.mysetting.questiondetail_content');
            //set mode is update
            $mode = 'add';
        }
        return $this->view('web::questionaire.index', array('data' => $data, 'db_error' => $db_error, 'mode' => $mode ));
    }

    /**
     * this function is used to update question detail
     *
     * @return void
     */
    public function postUpdate()
    {
        //get input request
        $input = $this->getRequestInputs();
        $bankType = $this->getBankTypeID();
        $coursecode = self::COURSECODE;
        $mode ='add';
        //get content array
        $contentArr = $input['cont'];
        $data = QuestionDetail::where('bankcode', $bankType)
                                ->where('coursecode', $coursecode)
                                ->orderBy('questno', 'asc')->get();
        if(count($data)!=0) {
          $mode ='update';
        }
        if(count($contentArr) != count($data) && $mode =='update') {
          //error
        }
        //get flag array
        $flagArr = isset($input['openflg']) ? $input['openflg'] : [];

        $idx =0;
        foreach ($contentArr as $key => $value) {
            //prepare data to update
            $updateData = [
                            'cont' => $value,
                            'openflg' => isset($flagArr[$idx]) ? 1 : 0,
                        ];
            if($mode == 'update'){
                //update questiondetail data
                $row = $data[$idx];
                $priKey = $row['questno'];
                $updateData['openflg'] = isset($flagArr[$priKey]) ? 1 : 0;
                QuestionDetail::where('bankcode', $this->getBankTypeID())
                                ->where('coursecode', self::COURSECODE )
                                ->where('questno', $priKey )
                                ->update($updateData);
            } else {
                //create data
                $insertData = new QuestionDetail();
                $insertData->bankcode = $this->getBankTypeID();
                $insertData->coursecode = self::COURSECODE;
                $insertData->questno = $key;
                $insertData->cont = $value;
                $insertData->openflg = (array_key_exists($key, $flagArr)) ? 1 : 0;
                $insertData->save();
            }
          $idx++;
        }
        //redirect to WM006
        return redirect()->route('action-questionaire-update');
    }

}
