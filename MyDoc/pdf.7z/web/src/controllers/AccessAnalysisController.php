<?php

namespace Pms\Web;

use Validator;
use DB;
use Pms\Web\AccessData;
use Pms\Web\QuestionData;

use Pms\Base\BaseController;
use Pms\Base\ProductMaster;

class AccessAnalysisController extends BaseController
{

    CONST COURSECODE = 1;
    protected $errorSystem ='';

    public function __construct()
    {
        parent::__construct();
        $this->screenID ='WM005';
        $this->titlePage = 'アクセス解析';
    }


    /**
    * this function is used to load analysis data
    *
    * @return void
    */
    public function init()
    {
        parent::init();
        //get input request
        $input = $this->getRequestInputs();
        //get bank type from URL
        $bankType = $this->getBankTypeID();
        //get master product category
        $m_product_category_master = ProductMaster::where('bankcode', $this->getBankTypeID() )->get();
        if(count($m_product_category_master) > 0) {
            $m_product_category_master = $m_product_category_master->toArray();
        }
        $m_product_category = [];
        foreach ($m_product_category_master as $key => $value) {
            $m_product_category[substr($value['productcode'],1,3)] = $value['productname'];
        }
        //get coursecode from input
        //$courseCode = self::COURSECODE;
        $courseCode = isset($input['coursecode']) ? $input['coursecode'] : '';
        //set default db error
        $db_error = false;
        $no_record = false;

        //get first date of this current month
        $beginDate =  date('Ym01');
        //get end date of current month
        $endDate = date('Ymt');
        //get begin month from current month
        $beginMonth = date("Ym01", strtotime(date("Y-m-01")." -5 months"));
        //get current month
        $endMonth = date("Ym31", strtotime(date("Y-m-d")));

        if (\Request::isMethod('post')) {
            
            $validator = Validator::make($input, config('web.rules.access_analysis_search_rules') );
            if ($validator->fails()) {
                return redirect()->back()->withInput()->withErrors($validator);
            }

            //use post variable to keep old value when click UPDATE 更新 button
            $post = $input;
            //get coursecode from input
            $courseCode = isset($input['coursecode']) ? $input['coursecode'] : '';
            //set beginDate & endDate when click  Update  button
            $beginDate = $input['dateFrom'];
            $endDate = $input['dateTo'];
            $beginMonth = date_create_from_format('Y-m-d', $input['dateTo'])
            ->modify('-5 month')->format('Ym').'01';
            $endMonth = date_create_from_format('Y-m-d', $input['dateTo'])
            ->format('Ym').'31';
        } else {
            $post = [];
        }

        //Process of executing data
        $data = $this->getData($bankType, $courseCode, $beginDate, $endDate, $beginMonth, $endMonth);
        //display data
        return $this->view('web::accessanalysis.index', [
                                                    'post'               => $post,
                                                    'data'               => $data,
                                                    'dateFrom'           => $beginDate,
                                                    'dateTo'             => $endDate,
                                                    'm_product_category' => $m_product_category,
                        ]);
    }

    /**
     * this function is used to get all data for this screen: number of access (アクセス数),  number of application (申込数)
     *
     * @param [type] $bankType
     * @param [type] $courseCode
     * @param [type] $beginDate
     * @param [type] $endDate
     * @param [type] $beginMonth
     * @param [type] $endMonth
     * @return void
     */
    public function getData($bankType, $courseCode, $beginDate, $endDate, $beginMonth, $endMonth)
    {
        //Create carrier array condition
        $carierArrPC = array( $this->config['carier_master_full']['PC_WEB']);
        $carierArrSP = array($this->config['carier_master_full']['SP'], $this->config['carier_master_full']['SP_WEB']);

        //Step 1: Get data from database
        //Step 2.1: get access data of PC by current month
        $resultAccPC = $this->searchDataFromAccesData($bankType, $courseCode, $carierArrPC, $beginDate, $endDate );
        $resultAppPC = $this->searchDataFromQuestionData($bankType, $courseCode, $carierArrPC, $beginDate, $endDate );
        $resultAccPC6Month = $this->searchDataFromAccesData($bankType, $courseCode, $carierArrPC, $beginMonth, $endMonth );
        $resultAppPC6Month = $this->searchDataFromQuestionData($bankType, $courseCode, $carierArrPC, $beginMonth, $endMonth );

        //Step 2.2: get access data of SP by current month
        $resultAccSP = $this->searchDataFromAccesData($bankType, $courseCode, $carierArrSP, $beginDate, $endDate );
        $resultAppSP = $this->searchDataFromQuestionData($bankType, $courseCode, $carierArrSP, $beginDate, $endDate );
        $resultAccSP6Month = $this->searchDataFromAccesData($bankType, $courseCode, $carierArrSP, $beginMonth, $endMonth );
        $resultAppSP6Month = $this->searchDataFromQuestionData($bankType, $courseCode, $carierArrSP, $beginMonth, $endMonth );

        //Step 2: fetch data and sort it
        // Step 3.1: fetch data by hour
        $countByHour  = $this->getNumberOfDay($resultAccPC, $resultAccSP, $resultAppPC, $resultAppSP);
        //Step 3.2: fetch data by month
        $countByMonth = $this->getNumberOfSixRecentMonth($beginMonth, $resultAccPC6Month, $resultAccSP6Month, $resultAppPC6Month, $resultAppSP6Month);

        // Step 3: combine result to array data
        $data = ['countByHour' => $countByHour, 'countByMonth' => $countByMonth];

        return $data;
    }

    /**
     * this function is used to get access data アクセス数 from table AccessData
     *
     * @param [type] $bankType
     * @param [type] $courseCode
     * @param [type] $device
     * @param [type] $beginDate
     * @param [type] $endDate
     * @param [type] $mode
     * @return void
     */
    public function searchDataFromAccesData($bankType, $courseCode, $device, $beginDate, $endDate)
    {
        //Process to execute query to get data
        try {
              $returnData = AccessData::select( DB::raw('DATE_FORMAT(acdate,"%Y%m%d%H%i%s")  as timezone, COUNT(bankcode) as number_access'))
                              ->whereBetween('acdate', [$beginDate, $endDate])
                              ->whereIn('career', $device)
                              ->where('bankcode', $bankType);
              if($courseCode !='') {
                $returnData = $returnData->where('coursecode', $courseCode);
              }
              $returnData = $returnData->get();
        } catch (\PDOException $e) {
            //set db_error
            return $this->errorSystem ='db_error';
        }
        return $returnData;
    }

    /**
     * this function is used to get number of application (申込数) from table QuestionData
     *
     * @param [type] $bankType
     * @param [type] $courseCode
     * @param [type] $device
     * @param [type] $beginDate
     * @param [type] $endDate
     * @param [type] $mode
     * @return void
     */
    public function searchDataFromQuestionData($bankType, $courseCode, $device, $beginDate, $endDate )
    {
        //define default return data
        $returnData =  [];

        //Process to execute query to get data
        try {
                $returnData = QuestionData::select( DB::raw('DATE_FORMAT(inputdate, "%Y%m%d%H%i%s")  as timezone, COUNT(bankcode) as number_access'))
                                ->whereBetween('inputdate', [$beginDate, $endDate])
                                ->where('bankcode', $bankType)
                                ->where('career', $device)
                                ->groupBy('timezone');
                if($courseCode !='') {
                  $returnData = $returnData->where('coursecode', $courseCode);
                }
                $returnData = $returnData->get();
                if(count($returnData) > 0) {
                    $returnData = $returnData->toArray();
                } else {
                    $returnData = [];
                }
        } catch (\PDOException $e) {
            //set db_error
            return 'db_error';
        }
        return $returnData;
    }


    private function getNumberOfDay($resultAccPC, $resultAccSP, $resultAppPC, $resultAppSP)
    {
        for ($hour = 0; $hour <=23; $hour++) {
          $hBegin = $hour>9? $hour.'0000':'0'.$hour.'0000';
          $hEnd = ($hour+1)>9? ($hour+1).'0000':'0'.($hour+1).'0000';
          $countAccPC[$hour] = $this->countDTime($resultAccPC,$hBegin,$hEnd);
          $countAccSP[$hour] = $this->countDTime($resultAccSP,$hBegin,$hEnd);
          $countAppPC[$hour] = $this->countDTime($resultAppPC,$hBegin,$hEnd);
          $countAppSP[$hour] = $this->countDTime($resultAppSP,$hBegin,$hEnd);
        }
        return ['countAccPC' => $countAccPC, 'countAccSP' => $countAccSP, 'countAppPC' => $countAppPC, 'countAppSP' => $countAppSP];
    }

    /**
     * this function is used to get number of six recent month from current date time
     *
     * @return $finalMonth
     */
    private function getNumberOfSixRecentMonth($beginMonth, $resultAccPC6Month, $resultAccSP6Month, $resultAppPC6Month, $resultAppSP6Month)
    {
        $month=date_create_from_format('Ymd', $beginMonth)->format('m')+0;
        for ($i = 0; $i < 6; $i++) {
            $begin = date_create_from_format('Ymd', $beginMonth);
            $begin->modify('+'.$i.' month');
            $end = date_create_from_format('Ymd', $beginMonth);
            $end->modify('+'.($i+1).' month');
            $month = $month >12? $month-12:$month;
            $countAccMPC[$month]= $this->countMTime($resultAccPC6Month,$begin->format('Ymd'),$end->format('Ymd'));
            $countAccMSP[$month]= $this->countMTime($resultAccSP6Month,$begin->format('Ymd'),$end->format('Ymd'));
            $countAppMPC[$month]= $this->countMTime($resultAppPC6Month,$begin->format('Ymd'),$end->format('Ymd'));
            $countAppMSP[$month]= $this->countMTime($resultAppSP6Month,$begin->format('Ymd'),$end->format('Ymd'));
            $month++;
        }
        return ['countAccMPC' => $countAccMPC, 'countAccMSP' => $countAccMSP, 'countAppMPC' => $countAppMPC, 'countAppMSP' => $countAppMSP];
    }

    private function countMTime($accData, $beginDate, $endDate){
      $count =0;
      foreach ($accData as $k => $val) {
        if($val['timezone']>= $beginDate.'000000' && $val['timezone']< $endDate.'000000') {
          $count +=$val['number_access'];
        }
      }
      return $count;
    }

    private function countDTime($accData, $beginHour, $endHour){
      $count =0;
      foreach ($accData as $k => $val) {
        if(substr($val['timezone'],8,6)>= $beginHour && substr($val['timezone'],8,6)< $endHour) {
          $count +=$val['number_access'];
        }
      }
      return $count;
    }

    function update() {
      $input = $this->getRequestInputs();
      $bankType = $this->getBankTypeID();
      //get master product category
      $query =DB::table('productmaster')->select();//dd($query->get());
      $m_product_category = $query->get();//config('web.mysetting.product_loan_category');
      //get coursecode from input
      //$courseCode = self::COURSECODE;
      $courseCode = isset($input['coursecode']) ? $input['coursecode'] : '';
      $beginDate = $input['dateFrom'];
      $endDate = $input['dateTo'];
      $data = $this->getData($bankType, $courseCode, $beginDate, $endDate, $beginMonth, $endMonth);
      return $this->view('web::accessanalysis.index', [
                                                  'post'               => $post,
                                                  'data'               => $data,
                                                  'dateFrom'           => $beginDate,
                                                  'dateTo'             => $endDate,
                                                  'm_product_category' => $m_product_category,
                                                  'db_error'           => $data['db_error'],
                                                  'no_record'          => $data['no_record'],
                      ]);
    }

}
