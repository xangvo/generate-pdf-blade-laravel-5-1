<?php

namespace Pms\Web;

use Pms\Base\BaseController;
use Auth;
use Validator;
use DB;
use Pms\Batch\BatchData;
use Request ;



class CalendarListController extends BaseController
{


    public function __construct() {
        parent::__construct();
        $this->screenID = 'WM003';
        $this->titlePage = 'カレンダー画面';
    }


   /**
     * this  function is used to show calendar data
     * screen ID: WM003
     * @return void
     */
    public function init()
    {
        parent::init();
        //Get bank_type from URL
        $bankType = $this->getBankTypeID();
        //get current month
        $month =  date('Ym');
        $monthParam =  date('m');
        // test 
        // $month = "201802";
        // $monthParam = '02';
        
        //get previous month
        $previousMonth = date('Ym',  strtotime($month . "01 -1 month"));
        $previousMonthParam = date('m',  strtotime($month . "01 -1 month"));

        //get data from database
        $dataMonth =  BatchData::where('bankcode',$bankType )
                                ->where('coursecode',1 )
                                ->where('batchtype',1 )
                                ->where(DB::raw("left(day,2)"), $monthParam)
                                ->get();
        $dataPreviousMonth =  BatchData::where('bankcode',$bankType )
                                ->where('coursecode',1 )
                                ->where('batchtype',1 )
                                ->where(DB::raw("left(day,2)"), $previousMonthParam)
                                ->get();
        //create calendar for month and previousMonth
        $calMonth = $this->makeCalendarArray($month, $dataMonth);
        $callPreviousMonth = $this->makeCalendarArray($previousMonth, $dataPreviousMonth);
        $data = [];
        return $this->view( 'web::calendar.index',
                            [ 
                                'currentMonth'      => $month,
                                'previousMonth'     => $previousMonth,
                                'calMonth'          => $calMonth,
                                'callPreviousMonth' => $callPreviousMonth,
                            ]
                        );

    }


    /**
     * this  function is used for xxxxx
     * screen ID: WM003
     */
    public function postUpdate(Request $request)
    {
        return redirect()->route('action-campaign-list');  
    }

    private function makeCalendarArray($month, $dataOfMonth)
    {
        //create array
        $cal = array(42);
        //get date of week
        $date = $month.'01'; //2018071
        $dayOfWeek = date('w', strtotime($date));
        if($dayOfWeek == 0) {
            $dayOfWeek = 6;
        } else {
            $dayOfWeek = $dayOfWeek -1;
        }
        //get number of date in month
        $dayOfMonth = cal_days_in_month(CAL_GREGORIAN, substr($month, 4), substr( $month ,0,4 ));
        
        for($day = 0; $day < 42; $day ++) {
            if(($dayOfWeek <= $day) && ($day < ($dayOfWeek + $dayOfMonth )))
            {
                $date = ($day+1) <=9? "0".($day+1): ($day+1);
                // $cal[$day] =  ['isDay' => true, 'num' => $num ,'day' => ($day - $dayOfWeek + 1 )];
                $cal[$day] =  ['isDay' => true, 'day' => ($day - $dayOfWeek + 1 )];
            } else {
                $cal[$day] =  ['isDay' => false];
            }
        }

        //get data for this processing month
        for($day = 0; $day < 42; $day ++) {
            if((0 <= $day) && ($day <  $dayOfMonth ))
            {
                $date = ($day+1) <=9? "0".($day+1): ($day+1);
                $num = $this->getCountDataByDate($date, $dataOfMonth);
                $cal[ $day + $dayOfWeek ]['num'] = $num ;
               
            }
            
        }
        return $cal;
    }

    private function getCountDataByDate($date, $dataOfMonth)
    {
        for($index = 0; $index < count($dataOfMonth); $index++) {
                if(substr($dataOfMonth[$index]->day, 2, 2) == $date ){
                    return $dataOfMonth[$index]->num;
                }
        }

    }
}
