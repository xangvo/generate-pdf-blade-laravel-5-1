<?php

namespace Pms\Web;

use Illuminate\Support\ServiceProvider;

class WebServiceProvider extends ServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = false;

    /**
     * Bootstrap the application events.
     */
    public function boot()
    {
        // Autoload class
        require __DIR__.'/../vendor/autoload.php';

        // Load routes
        if (!$this->app->routesAreCached()) {
            require __DIR__.'/WebRoutes.php';
        }

        // Add views;
        $this->loadViewsFrom(__DIR__.'/views', 'web');

        // Publish
        $this->publishes([
            __DIR__.'/views' => base_path('pms/web/views'),
        ]);
    }

    /**
     * Register the service provider.
     */
    public function register()
    {
        // Config
        $this->mergeConfigFrom(__DIR__.'/config/rules.php', 'web.rules');
        $this->mergeConfigFrom(__DIR__.'/config/mysetting.php', 'web.mysetting');
        $this->mergeConfigFrom(__DIR__.'/config/items.php', 'web.items');
        $this->mergeConfigFrom(__DIR__.'/config/export_columns.php', 'web.export_columns');

        // Controllers
        $this->app->make('Pms\Web\WebListController');
        $this->app->make('Pms\Web\ShopManageController');
        $this->app->make('Pms\Web\QuestionaireModifyController');
        $this->app->make('Pms\Web\EntryDataDownloadController');
        $this->app->make('Pms\Web\DataListDisplayController');
        $this->app->make('Pms\Web\CalendarListController');
        $this->app->make('Pms\Web\AccessAnalysisController');
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return array();
    }
}
