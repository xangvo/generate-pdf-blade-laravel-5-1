<?php

Route::group(['namespace' => 'Pms\\Web'], function () {
    Route::pattern('id', '[0-9]+');

//     Route::group(['middleware' => ['auth.admin', 'is_secure'], 'prefix' => 'WM'], function () {
    Route::group(['middleware' => ['http_only'], 'prefix' => 'WM'], function () {
        Route::any('WM001', [
                'as' => 'action-web-list',
                'uses' => 'WebListController@init'
                ]);

        Route::get('WM002', [
                'as' => 'action-web-entry-download-list',
                'uses' => 'EntryDataDownloadController@init'
                ]);
        
        Route::get('WM002/download', [
                'as' => 'action-web-entry-download-input',
                'uses' => 'EntryDataDownloadController@download'
        ]);

        Route::get('WM003', [
                'as'   => 'action-calendar-list',
                'uses' => 'CalendarListController@init'
                ]);
        Route::post('WM003', [
                'as'   => 'action-calendar-update',
                'uses' => 'CalendarListController@postUpdate'
                ]);

        Route::any('WM004', [
                'as'   => 'action-web-data-list-display',
                'uses' => 'DataListDisplayController@init'
                ]);

        Route::post('WM004/PDF', [
                'as'   => 'action-export-pdf-web-data-list',
                'uses' => 'DataListDisplayController@exportPDF'
                ]);

        Route::post('WM004/CSV', [
                'as'   => 'action-export-csv-web-data-list',
                'uses' => 'DataListDisplayController@exportCSV'
                ]);

        Route::any('WM005', [
                'as'   => 'action-web-access-analysis',
                'uses' => 'AccessAnalysisController@init'
                ]);

        Route::get('WM006', [
                'as'   => 'action-questionaire-edit',
                'uses' => 'QuestionaireModifyController@init'
                ]);
        Route::post('WM006', [
                'as'   => 'action-questionaire-update',
                'uses' => 'QuestionaireModifyController@postUpdate'
                ]);
        Route::get('WM007', [
                'as'   => 'action-shop-manage',
                'uses' => 'ShopManageController@init'
        ]);
        Route::post('WM007', [
                'as'   => 'action-shop-manage-update',
                'uses' => 'ShopManageController@postUpload'
        ]);
         Route::get('WM007/download', [
                'as'   => 'action-shop-download-csv',
                'uses' => 'ShopManageController@downloadCSV'
        ]);

    });
   
});
