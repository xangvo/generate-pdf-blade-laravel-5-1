@extends('adminlayout')
<link rel="stylesheet" href="{{asset('/form/css/style.css')}}">
@section('content')
@include('web::buttoncontrol')
<hr color="#1D9661" >
<center><font size="+1" style="font-weight: bold;">アクセス解析</font></center>

{!! Form::open(array('url' => 'WM/WM005', 'name' => 'frmRegist', 'files' => true)) !!}


        <table class="tableForm01">
        <tbody>
            <tr>
            <th>期間選択：</th>
            <td>
                <div class="inputWrap04">
                    @if($errors->has('dateFrom'))
                        <div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('dateFrom', '<p class="err_txt">:message</p>')!!}</b></div>
                    @endif
                    @if($errors->has('dateTo'))
                        <div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('dateTo', '<p class="err_txt">:message</p>')!!}</b></div>
                    @endif
                    <input type="date" class="@if($errors->has('dateFrom')) reqItem @endif" name="dateFrom" value="{{ (isset($post['dateFrom'])? $post['dateFrom']:date("Y-m-d", strtotime($dateFrom)) )  }}">
                    <span>～</span>
                    <input type="date" class="@if($errors->has('dateTo')) reqItem @endif" name="dateTo"  value="{{ isset($post['dateTo'])? $post['dateTo']:  date("Y-m-d", strtotime($dateTo)) }}">
                    <input type="submit" value="更新" class="btnT01" style="width:70px">
                </div>
            </td>
        </tr>

        <tr>
            <th>商品</th>
            <td>
                <div class="selectWrap01">
                    {!! Form::select('coursecode',  ['' => '選択してください'] + $m_product_category, isset($post['coursecode']) ? $post['coursecode']: '', ['id' => 'coursecode']) !!}
                </div>
            </td>
        </tr>
        </tbody>
        </table>

    {!! Form::close() !!}

<center style="user-select: text;">
<table style="user-select: text;">
<tbody style="user-select: text;"><tr style="user-select: text;">
<td style="user-select: text;">

<center style="user-select: text;"><font style="font-weight: bold; font-size: 14pt; user-select: text;">ＰＣ時間別アクセス数</font></center>



<!-- 0時～5時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
            @for ($i = 0; $i <= 5; $i++)
			<td class="head3" width="50px" align="right" style="user-select: text;">
				{{$i}}時
			</td>
            @endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

        @foreach($data['countByHour']['countAccPC'] as $key => $val)
            @if($key <=5)
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>
            @foreach($data['countByHour']['countAppPC'] as $key => $val)
                @if($key <=5)
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach
	</tr>
</tbody></table>
<!-- 6時～11時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
            @for ($i = 6; $i <= 11; $i++)
			<td class="head3" width="50px" align="right" style="user-select: text;">
				{{$i}}時
			</td>
            @endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>
        @foreach($data['countByHour']['countAccPC'] as $key => $val)
            @if(($key>=6) && ($key<=11))
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>

            @foreach($data['countByHour']['countAppPC'] as $key => $val)
            @if(($key>=6) && ($key<=11))
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
</tbody></table>
<!-- 12時～17時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
		@for ($i = 12; $i <= 17; $i++)
			<td class="head3" width="50px" align="right" style="user-select: text;">
				{{$i}}時
			</td>
		@endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

        @foreach($data['countByHour']['countAccPC'] as $key => $val)
            @if(($key>=12) && ($key<=17))
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>

		@foreach($data['countByHour']['countAppPC'] as $key => $val)
            @if(($key>=12) && ($key<=17))
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
</tbody></table>
<!-- 18時～23時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
            @for ($i = 18; $i <= 23; $i++)
			<td class="head3" width="50px" align="right" style="user-select: text;">
				{{$i}}時
			</td>
			@endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

        @foreach($data['countByHour']['countAccPC'] as $key => $val)
            @if(($key>=18) && ($key<=23))
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>

        @foreach($data['countByHour']['countAppPC'] as $key => $val)
            @if(($key>=18) && ($key<=23))
			<td class="td2" align="right" style="user-select: text;">
				{{$val}}件
			</td>
            @endif
        @endforeach

	</tr>
</tbody></table>

</td>
<td style="user-select: text;">



<center style="user-select: text;"><font style="font-weight: bold; font-size: 14pt; user-select: text;">スマートフォン時間別アクセス数</font></center>




<!-- 0時～5時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
        @for ($i = 0; $i <= 5; $i++)
			<td class="head3" width="50px" align="right" style="user-select: text;">
				{{$i}}時
			</td>
		@endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

			@foreach($data['countByHour']['countAccSP'] as $key => $val)
                @if(($key>=0) && ($key<=5))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach
        </td>

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>
            @foreach($data['countByHour']['countAppSP'] as $key => $val)
                @if(($key>=0) && ($key<=5))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
</tbody></table>
<!-- 6時～11時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
        @for ($i = 6; $i <= 11; $i++)
			<td class="head3" width="50px" align="right" style="user-select: text;">
				{{$i}}時
			</td>
		@endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

			@foreach($data['countByHour']['countAccSP'] as $key => $val)
                @if(($key>=6) && ($key<=11))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>

			@foreach($data['countByHour']['countAppSP'] as $key => $val)
                @if(($key>=6) && ($key<=11))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
</tbody></table>
<!-- 12時～17時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
            @for ($i = 12; $i <= 17; $i++)
                <td class="head3" width="50px" align="right" style="user-select: text;">
                    {{$i}}時
                </td>
            @endfor

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

			@foreach($data['countByHour']['countAccSP'] as $key => $val)
                @if(($key>=12) && ($key<=17))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>

			@foreach($data['countByHour']['countAppSP'] as $key => $val)
                @if(($key>=12) && ($key<=17))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
</tbody></table>
<!-- 18時～23時のアクセス解析 -->
<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
            @for ($i = 18; $i <= 23; $i++)
                <td class="head3" width="50px" align="right" style="user-select: text;">
                    {{$i}}時
                </td>
			@endfor
	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

			@foreach($data['countByHour']['countAccSP'] as $key => $val)
                @if(($key>=18) && ($key<=23))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>

			@foreach($data['countByHour']['countAppSP'] as $key => $val)
                @if(($key>=18) && ($key<=23))
                <td class="td2" align="right" style="user-select: text;">
                    {{$val}}件
                </td>
                @endif
            @endforeach

	</tr>
</tbody></table>




</td>
</tr>
</tbody></table>
</center>

<br style="user-select: text;">
<br style="user-select: text;">

<center style="user-select: text;">

<table style="user-select: text;">
<tbody style="user-select: text;"><tr style="user-select: text;">
<td style="user-select: text;">


<center style="user-select: text;"><font style="font-weight: bold; font-size: 14pt; user-select: text;">PC月別アクセス数</font></center>




<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>
            @foreach($data['countByMonth']['countAccMPC'] as $key => $val)
                <td class="head3" width="50px" align="right" style="user-select: text;">
				{!!$key!!}月
                </td>
            @endforeach
	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>
            @foreach($data['countByMonth']['countAccMPC'] as $key => $val)
               <td class="td2" align="right" style="user-select: text;">
				{!!$val!!}件
                </td>
            @endforeach
	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>
            @foreach($data['countByMonth']['countAppMPC'] as $key => $val)
                <td class="td2" align="right" style="user-select: text;">
				{!!$val!!}件
                </td>
            @endforeach
	</tr>

</tbody></table>



</td>
<td style="user-select: text;">
<center style="user-select: text;"><font style="font-weight: bold; font-size: 14pt; user-select: text;">スマートフォン月別アクセス数</font></center>



<table class="list2" style="user-select: text;">
	<tbody style="user-select: text;"><tr style="user-select: text;">
		<td class="head3" width="80px" style="user-select: text;"></td>

            @foreach($data['countByMonth']['countAccMSP'] as $key => $val)
                <td class="head3" width="50px" align="right" style="user-select: text;">
				{!!$key!!}月
                </td>
            @endforeach
	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">アクセス数</td>

			 @foreach($data['countByMonth']['countAccMSP'] as $key => $val)
               <td class="td2" align="right" style="user-select: text;">
				{!!$val!!}件
                </td>
            @endforeach

	</tr>
	<tr style="user-select: text;">
		<td class="head3" style="user-select: text;">申込数</td>
			 @foreach($data['countByMonth']['countAppMSP'] as $key => $val)
                <td class="td2" align="right" style="user-select: text;">
				{!!$val!!}件
                </td>
            @endforeach
	</tr>
</tbody></table>


</td>
</tr>
</tbody></table>

</center>
<br style="user-select: text;">
<br style="user-select: text;">

@stop

@section('javascripts')
<script>

</script>
@stop
