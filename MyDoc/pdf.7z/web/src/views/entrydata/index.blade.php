@extends('adminlayout')

@section('content')
@include('web::buttoncontrol')

<section>
	<h1 class="h1Title01"><span class="titleInner">xxxxxxxxxxxx</span></h1>
	<a href={{route('action-calendar-list')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">カレンダー</span></a>
	@if($db_error)
		<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$db_error_msg!!}</b></div><br>
	@endif

	@if(count($data['batchData'])==0)
		<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$no_record_msg!!}</b></div><br>
	@endif

	<table class="tableRepeat jsTableRepeatY">
		<thead>
			<tr class="vMiddle">
				<th class="jsHeadX tableTitle02 w30p tBold">時間</th>
				<th class="jsHeadX tableTitle02 w25p tBold">件数</th>
				<th class="jsHeadX tableTitle02 w15p">DL</th>
				<th class="jsHeadX tableTitle02 w15p">ファイル</th>
				<th class="jsHeadX tableTitle02 w15p">PDF</th>
			</tr>
		</thead>
		@foreach ($data['batchData'] as $r)
		<tbody>
			<tr>
				<th class="jsHeadY tableTitle01 tLeft tBold">{!! $batchType_TypeMap[$r['batchtype']]!!}</th>
				<td class="tBold"> {!! $r['num']!!}</td>
				<td class="tBold"> {!! $r['downloadflg']!!}</td>
				<td class="tBold"><a href="WM002/download?file={!!$r['file']!!}&type=txt" target="_blank" >{!! $r['file']!!}</a></td>
				<td class="tBold"><a href="WM002/download?file={!!$r['file2']!!}&type=pdf" target="_blank">{!! $r['file2']!!}</a></td>
			</tr>
		</tbody>
		@endforeach
	</table>
</section>

@stop

@section('javascripts')

@stop
