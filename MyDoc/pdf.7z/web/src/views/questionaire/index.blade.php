@extends('adminlayout')

@section('content')
@include('web::buttoncontrol')
<section>
	<hr color="#1D9661" >
    <center><font size="+1" style="font-weight: bold;">アンケート内容一覧</font>
    <p>ここで登録されている内容がアンケート結果に表示されます</p></center>

    {!! Form::open(array('url' => 'WM/WM006', 'id' => 'updateForm')) !!}
    @if($db_error)
        <div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!config('web.mysetting.DB_error')!!}</b></div><br>
    @endif
    @if(count($data) > 0)
        {{--  <table class="tableRepeat jsTableRepeatY">  --}}
        <table class="tableRepeat">
            <thead>
                <tr class="vMiddle">
                    <th class="jsHeadX tableTitle02 w10p tBold">コード</th>
                    <th class="jsHeadX tableTitle02 w50p tBold">アンケート内容</th>
                    <th class="jsHeadX tableTitle02 w10p tBold">公開</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($data as $key =>  $r)
                <tr>
                    <td class="jsHeadY tableTitle01 tCenter tBold"> {{$r['questno']}}</td>
                    <td class="tBold tCenter"> <input type="text" class="inputW04" name="cont[{!!$r['questno']!!}]"  id="{!!$r['questno']!!}" value="{{ $r['cont']}}" style="border: solid 1px #3c3434; height: 30px; margin: 0 0px; ">  </td>
                    <td class="tBold tCenter"><input type="checkbox" @if($r['openflg']) checked @endif name="openflg[{!!$r['questno']!!}]"></td>
                </tr>
            @endforeach
            </tbody>
        </table>
        {{--  <a href={{route('action-questionaire-update')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">更新</span></a>  --}}
        <input type="hidden" id="mode" name="mode" value="{{$mode}}">
        <div style="margin: 0 auto; text-align: center">
            <input type="submit" value="更新" class="btnT01">
        </div>

    @endif
    {!! Form::close() !!}

</section>

@stop

@section('javascripts')
<script>
$("#updateForm").submit(function() {
    if(confirm('変更してもよろしいですか？')){
            return true;
		}
    return false;
});

</script>
@stop
