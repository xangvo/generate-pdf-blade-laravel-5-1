@extends('adminlayout')

@section('content')
@include('web::buttoncontrol')
<section>

<hr color="#1D9661" >
    <center><font size="+1" style="font-weight: bold;">店舗情報管理</font>(現在の店舗情報 登録数：{!! count($data) !!})</center>

{!! Form::open(array('url' => 'WM/WM007', 'id' => 'updateForm' , 'files' => true )) !!}
    @if($db_error)
        <div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!config('web.mysetting.DB_error')!!}</b></div><br>
    @endif
        <table class="tableForm01">
            <tbody>
                <tr>
                <td>
                    <a href="{{route('action-shop-download-csv')}}" target="_blank"  class="btnT01 glyphArrowCircleRight"><span>↓ダウンロード</span></a>
                </td>
                <td>
                    <input id="branchCodeFile"  type="file" name="branchCodeFile"  accept=".csv"  >
                        @foreach ($errors->all() as $error)
                            <div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{{ $error }}</b></div><br>
                        @endforeach
                    {!! Form::submit('↑アプロード', array('class'=>'btnT01  btnInputWMiddle','style' => 'width:auto;    margin-left: 0px', 'id'=>'uploadButton' ,  'onclick'=>'return validate();')) !!}
                </td>
                </tr>

            </tbody>
        </table>

    @if((count($data) > 0) && (count($errors) == 0)) 
        <table class="tableRepeat jsTableRepeatY">
         {{--  <table class="tableRepeat">  --}}
            <tdead>
                <tr class="vMiddle">
                    <th class="jsHeadX tableTitle02 w10p tBold">コード</th>
                    <th class="jsHeadX tableTitle02 w15p tBold">店舗名</th>
                    <th class="jsHeadX tableTitle02 w15p tBold">店舗名（カナ）</th>
                </tr>
            </thead>
                <tbody>
                    @foreach ($data as $key =>  $r)
                        <tr>
                            <td class="jsHeadY tableTitle01 tCenter"> {!! $r['code']!!}</td>
                            <td >{!! $r['name']!!}  </td>
                            <td >{!! $r['kana']!!}</td>
                        </tr>
                    @endforeach
                </tbody>
        </table>
    @endif
{!! Form::close() !!}
<section>


@stop

@section('javascripts')
<script>
$(document).ready(function(){
//    $('#uploadButton').on('click',function(){
//        if( $('#branchCodeFile').val() !=''){
//            alert("here");
//            return true;
//        } else {
//            //if there is no upload file, reload page
//            location.reload();
//        }
//    });
});

function validate(){
    var valid = false;
    var val = $("#branchCodeFile").val();
    if(val == ''){
        // your validation error action
        valid = false;
        location.reload();
    } else {
        valid = true;
    }
    return valid;
}
</script>
@stop
