@extends('adminlayout')


@section('content')
@include('web::buttoncontrol')

@stop

@section('javascripts')
<script>
	
</script>
@stop
