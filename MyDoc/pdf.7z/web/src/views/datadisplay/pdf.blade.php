<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>{{ $pdfFileName }}</title>

        <!-- Styles -->
        <style>
            @font-face {
                font-family: ipag;
                font-style: normal;
                font-weight: normal;
                src: url('{{ storage_path('fonts/ipag.ttf') }}') format('truetype');
            }
            @font-face {
                font-family: ipag;
                font-style: bold;
                font-weight: bold;
                src: url('{{ storage_path('fonts/ipag.ttf') }}') format('truetype');
            }

            html, body {
                font-family: ipag !important;
                background-color: #fff;
                color: #000;
                margin: 0;
            }
            .content{
                margin: 20px;
                font-size: 12px;
            }
            /* Clear floats after the columns */
            .content:after {
                content: "";
                display: table;
                clear: both;
            }
            .header{
                margin: 20px;
                padding: 3px 2px;
                border: 1px solid black;
            }
            .footer {
                margin: 30px 20px 0px 20px;
                font-weight: bold;
            }
            .footer .box {
                border: 1px solid black;
                height: 80px;
            }
            table {
                border-spacing: 0;
            }
   
            table td,
            table th {
                vertical-align: top;
            }
            .th-class {
                padding: 4px;
                font-weight: bold;
                border: 0.5px solid black;
 
                background: #ccc;
            }
            .td-class {
                border: 0.5px solid black;
                padding: 4px;
                width: 210px;
            }

            .page-break {
                page-break-after: always;
            }
        </style>
    </head>
    <body>
        <?php $pageNumber = 0; ?>
        @foreach ($data as $pageData)
            <?php $pageNumber++; ?>
            <div class="header">
                <span>りそな銀行：クイックカードローンウェブ申込</span>
                <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $pdfFileName }} &nbsp; {{ $pageNumber }} / {{ $total }}</span>
            </div>
        
            <div class="content">
                <table style="width: 100%">
                    <tr>
                        <td>
                            <table style="width: 370px;">
                                @foreach ($exportLeftColumns as $key => $val)
                                    <tr>
                                        <th class="th-class">{{ $key or '' }}</th> 
                                        <td class="td-class">{{ $pageData->$val or '' }}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </td> 
                        <td>
                            <table style="width: 297px; float: right;" >
                                @foreach ($exportRightColumns as $key => $val)
                                    <tr>
                                        <th class="th-class">{{ $key or '' }}</th> 
                                        <td class="td-class">{{ $pageData->$val or '' }}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="footer">
                銀行使用欄
                <div class="box">
                </div>
            </div>
            @if ($total > 1)
                <div class="page-break"></div>
            @endif
            
        @endforeach
    </body>
</html>