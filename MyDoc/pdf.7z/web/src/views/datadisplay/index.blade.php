@extends('adminlayout')
<link rel="stylesheet" href="{{asset('/form/css/myCustom.css')}}">

@section('content')
@include('web::buttoncontrol')

<hr color="#1D9661" >
<center><font size="+1" style="font-weight: bold;">データ一覧画面</font></center>

{!! Form::open(array('url' => 'WM/WM004', 'name' => 'frmRegist', 'files' => true)) !!}
	

	<table class="tableForm01">
	<tr>
		<th>申込日付を選択：</th>
		<td>
			<dl class="inputName01">
				@if($errors->has('dateFrom'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('dateFrom', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif
				@if($errors->has('dateTo'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('dateTo', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif
				<input type="date" class="date @if($errors->has('dateFrom')) reqItem inputW04  @endif" name="dateFrom" value="{{ $dateFrom}}">
				<span>～</span>
				<input type="date" class="date @if($errors->has('dateTo')) reqItem inputW04 @endif" name="dateTo"  value="{{  $dateTo }}">
			</dl>
		</td>
	</tr>

	<tr>
		<th>商品</th>
		<td class="w75p">
			<dl class="inputName01">
				@if($errors->has('coursecode'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('coursecode', '<p class="err_txt">:message</p>')!!}</b></div>
					@endif
					<div class="selectWrap01">
						{!! Form::select('coursecode', ['' => '選択してください'] + $m_product_category, isset($post['coursecode'])? $post['coursecode']:'', array('id' => 'coursecode', 'class' => 'inputW04')) !!}
					</div>

			</dl>
		</td>
	</tr>


	<tr>
		<th>受付番号：</th>
		<td>
			<dl class="inputName01">
				@if($errors->has('receptionNumber'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('receptionNumber', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif
				<dd><input type="text"  style="margin: 0 0px;"  maxlength="100"  class="@if($errors->has('receptionNumber')) reqItem @endif inputW04 customCss"  name="receptionNumber" value="{{ old('receptionNumber') ? old('receptionNumber') : (isset($post['receptionNumber'])? $post['receptionNumber']:'') }}"></dd>
			</dl>
		</td>
	</tr>


	<tr>
		<th>氏名：</th>
		<td class="w75p">
			<dl class="inputName01">
				@if($errors->has('userSur1name'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('userSur1name', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif
				@if($errors->has('userGiven1name'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('userGiven1name', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif

				<input type="text"  style="margin: 0 0px;"  class="@if($errors->has('userSur1name')) reqItem @endif inputW04" maxlength="30"  name="userSur1name" value="{{ old('userSur1name') ? old('userSur1name') : (isset($post['userSur1name'])? $post['userSur1name']:'') }}">
				<input type="text"   class="@if($errors->has('userGiven1name')) reqItem @endif inputW04"   maxlength="30"  name="userGiven1name" value="{{ old('userGiven1name') ? old('userGiven1name') : (isset($post['userGiven1name'])? $post['userGiven1name']:'') }}">

			</dl>
		</td>
	</tr>


	<tr>
		<th>氏名(カナ)：</th>
		<td>
			<dl class="inputName01">
				@if($errors->has('userSur1name_kana'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('userSur1name_kana', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif
				@if($errors->has('userGiven1name_kana'))
					<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!$errors->first('userGiven1name_kana', '<p class="err_txt">:message</p>')!!}</b></div>
				@endif

				<input type="text"  style="margin: 0 0px;"  class="@if($errors->has('userSur1name_kana')) reqItem @endif inputW04"  maxlength="30" name="userSur1name_kana" value="{{ old('userSur1name_kana') ? old('userSur1name_kana') : (isset($post['userSur1name_kana'])? $post['userSur1name_kana']:'') }}">
				<input type="text" class="@if($errors->has('userGiven1name_kana')) reqItem @endif inputW04"  maxlength="30"  name="userGiven1name_kana" value="{{ old('userGiven1name_kana') ? old('userGiven1name_kana') : (isset($post['userGiven1name_kana'])? $post['userGiven1name_kana']:'') }}">
			</dl>
		</td>
	</tr>
	
	</table>
	<input type="submit" value="表示" name="view" style="width:80px;"><br>
	@if($errors->has('db_error'))
		<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!config('web.mysetting.DB_error')!!}</b></div><br>
	@endif
	@if(count($data) ==0 && $flgSearch)
		<div><label for="name01"></label><span><div style="color:#ff0000;" class="error2"><b>{!!config('web.mysetting.no_record')!!}</b></div><br>
	@endif

	@if(count($data) !=0)
			<div id="textbox">
			<p class="alignleft">{!!$total!!}件中 {!! $data->firstItem() !!}～{!! $data->lastItem() !!}件を表示</p>
			<p class="alignright">{!! $data->currentPage() !!}/{!! $data->lastPage() !!} page</p>
			</div>
			<p></p>
			
			<div style="margin: 0 auto; text-align: center">
				@if(isset($data))
					@if($data->currentPage() > 1)
							<a href="{{ $data->previousPageUrl() }}">前へ</a>
					@endif

				@if($data->hasMorePages())
						<a href="{{ $data->nextPageUrl() }}">次へ</a>
					@endif
				@endif
			</div>
			
		<table class="tableRepeat jsTableRepeatY">
			<thead>
				<tr class="vMiddle">
					<th class="jsHeadX tableTitle02 w10p tBold">受付番号</th>
					<th class="jsHeadX tableTitle02 w10p tBold">氏名 </th>
					<th class="jsHeadX tableTitle02 w10p tBold">氏名（カナ）</th>
					<th class="jsHeadX tableTitle02 w10p tBold">メールアドレス</th>
					<th class="jsHeadX tableTitle02 w10p tBold">申込時刻  </th>
					<th class="jsHeadX tableTitle02 w10p tBold">メール送信結果</th>
				</tr>
			</thead>
			<tbody>
			@foreach ($data as $r)
				<tr>
					<td class="jsHeadY tableTitle01 tLeft tBold">{!!$r->receptionNumber!!}</td>
					<td class="tLeft tBold">@if(!empty($r->userSurname)){!!$r->userSurname!!}@else null @endif @if(!empty($r->userGivenname)){!!$r->userGivenname!!}@else null @endif</td>
					<td class="tLeft tBold">@if(!empty($r->userSurname_kana)){!!$r->userSurname_kana!!}@else null @endif @if(!empty($r->userGivenname_kana)){!!$r->userGivenname_kana!!}@else null @endif</td>
					<td class="tLeft tBold">{!!$r->emailAddress!!}</id>
					<td class="tLeft tBold">{!!$r->receptionDate!!}</td>
					<td class="tLeft tBold">@if($r->mailsendFlag==1)〇@else×@endif</td>
				</tr>
			@endforeach				
			</tbody>
		</table>
		<div style="margin: 0 auto; text-align: center">
			@if(isset($data))
				@if($data->currentPage() > 1)
					<a href="{{ $data->previousPageUrl() }}">前へ</a>
				@endif

			@if($data->hasMorePages())
					<a href="{{ $data->nextPageUrl() }}">次へ</a>
				@endif
			@endif
		</div>	
	@endif
	<div style="margin: 0 auto; text-align: right">
		<input type="button" onclick="exportCSVButton();" value="CSV出力" class="btnT03">
		<input type="button" onclick="exportPDFButton();" value="PDF出力" class="btnT03">
	</div>
{!! Form::close() !!}

{!! Form::open(array('url' => '', 'id' => 'frmExport', 'name' => 'frmExport')) !!}
	{!! Form::hidden('dateFrom', isset($dateFrom) ? date("Y-m-d", strtotime($dateFrom)) : '') !!}
	{!! Form::hidden('dateTo', isset($dateTo) ? date("Y-m-d", strtotime($dateTo)) : '' ) !!}
	{!! Form::hidden('coursecode', isset($post['coursecode']) ? $post['coursecode'] : '' ) !!}
	{!! Form::hidden('receptionNumber', isset($post['receptionNumber'])? $post['receptionNumber']: old('receptionNumber')  ) !!}
	{!! Form::hidden('userSurname', isset($post['userSurname'])? $post['userSurname']: old('userSurname')  ) !!}
	{!! Form::hidden('userGivenname', isset($post['userGivenname'])? $post['userGivenname']: old('userGivenname')  ) !!}
	{!! Form::hidden('userSurname_kana', isset($post['userSurname_kana'])? $post['userSurname_kana']: old('userSurname_kana')  ) !!}
	{!! Form::hidden('userGivenname_kana', isset($post['userGivenname_kana'])? $post['userGivenname_kana']: old('userGivenname_kana')  ) !!}
{!! Form::close() !!}

@stop

@section('javascripts')
<script>
$(document).ready(function(){
	$('.date').each(function(){
		if ((GetIEVersion() > 0)  && GetIEVersion() <= 11) {
			$(this).val($(this).val().replace(new RegExp('-', 'g'),'/'));
		}
	});
});

function GetIEVersion() {
  var sAgent = window.navigator.userAgent;
  var Idx = sAgent.indexOf("MSIE");

  // If IE, return version number.
  if (Idx > 0) 
    return parseInt(sAgent.substring(Idx+ 5, sAgent.indexOf(".", Idx)));

  // If IE 11 then look for Updated user agent string.
  else if (!!navigator.userAgent.match(/Trident\/7\./)) 
    return 11;

  else
    return 0; //It is not IE
}

function exportPDFButton()
{
	$('#frmExport').attr('action', 'WM004/PDF');
	$('#frmExport').submit();
}
function exportCSVButton()
{
	$('#frmExport').attr('action', 'WM004/CSV');
	$('#frmExport').submit();
}
</script>
@stop
