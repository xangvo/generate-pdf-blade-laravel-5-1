@extends('adminlayout')
<link rel="stylesheet" href="{{asset('/form/css/modal.css')}}">

@section('content')
@include('web::buttoncontrol')

<div class="month"> 
  <ul>
    <li>{!! substr($currentMonth,0,4)!!}年{!! substr($currentMonth,4,2)!!}月</li>
  </ul>
</div>

<ul class="formModalList01 clear"> 
<li style="width: 13%">月</li>
  <li style="width: 13%">火</li>
  <li style="width: 13%">水</li>
  <li style="width: 13%">木</li>
  <li style="width: 13%">金</li>
  <li style="width: 13%">土</li>
  <li style="width: 13%">日</li>
@foreach ($calMonth as $key => $val)
    @if($key%7 ==0 )
     <li class="firstChild" style="width: 13%" >@if($val['isDay']){!!$val['day']!!}<br><a>@if(empty($val['num']))0 @else{!!$val['num']!!}@endif件</a>@endif</li>
    @else
        <li style="width: 13%" >@if($val['isDay']){!!$val['day']!!}<br><a>@if(empty($val['num']))0 @else{!!$val['num']!!}@endif件</a>@endif</li>
    @endif
@endforeach
</ul>

<div class="month"> 
  <ul>
    <li>{!! substr($previousMonth,0,4)!!}年{!! substr($previousMonth,4,2)!!}月</li>
  </ul>
</div>

<ul class="formModalList01 clear"> 
<li style="width: 13%">月</li>
<li style="width: 13%">火</li>
<li style="width: 13%">水</li>
<li style="width: 13%">木</li>
<li style="width: 13%">金</li>
<li style="width: 13%">土</li>
<li style="width: 13%">日</li>

<ul class="formModalList01 clear"> 
@foreach ($callPreviousMonth as $key => $val)
    @if($key%7 ==0 )
     <li class="firstChild" style="width: 13%" >@if($val['isDay']){!!$val['day']!!}<br><a>@if(empty($val['num']))0 @else{!!$val['num']!!}@endif件</a>@endif</li>
    @else
        <li style="width: 13%" >@if($val['isDay']){!!$val['day']!!}<br><a>@if(empty($val['num']))0 @else{!!$val['num']!!}@endif件</a>@endif</li>
    @endif
@endforeach
</ul>

@stop

@section('javascripts')
<script>
	
</script>
@stop
