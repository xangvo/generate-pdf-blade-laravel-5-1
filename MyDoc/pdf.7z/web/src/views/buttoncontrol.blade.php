<a href={{route('action-web-entry-download-list')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">ダウンロード</span></a>
<a href={{route('action-web-data-list-display')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">データ一覧表示</span></a>
<a href={{route('action-web-access-analysis')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">アクセス分析</span></a>
<a href="{!!$logoutURL!!}" class="btnT01 btnSMiddle glyphDoor"><span>セキュア共有システムに戻る</span></a>
<br>
<a href={{route('action-questionaire-edit')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">アンケート内容変更</span></a>
<a href={{route('action-shop-manage')}} class="btnT01 btnSMiddle glyphDoor" style="user-select: text;"><span style="user-select: text;">店舗情報管理</span></a>
